<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Verificacoes Controller
 *
 * @property \App\Model\Table\VerificacoesTable $Verificacoes
 *
 * @method \App\Model\Entity\Verificaco[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class VerificacoesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $verificacoes = $this->paginate($this->Verificacoes);

        $this->set(compact('verificacoes'));
    }

// Código para a busca
/*  // Descomente a linha abaixo e mova para o início, logo abaixo de use App\Controller\AppController;
	// E adapte corretamente para o seu controller
	//use Cake\Datasource\ConnectionManager;
    public function index()
    {        
		$conn = ConnectionManager::get('default');
		$driver = $conn->config()['driver']; // Outros: database, etc.
		
		if($driver == 'Cake\Database\Driver\Postgres'){
		    $this->paginate = [
		        'contain' => ['Users'],
		        'conditions' => ['or' => [
		            'Customers.name ilike' => '%' . $this->request->getQuery('search') . '%',
		            'Customers.phone ilike' => '%' . $this->request->getQuery('search') . '%'
		        ]],
		        'order' => ['Customers.id' => 'DESC' ]
		    ];
		}elseif($driver=='Cake\Database\Driver\Mysql'){
		    $this->paginate = [
		        'contain' => ['Users'],
		        'conditions' => ['or' => [
		            'Customers.name like' => '%' . $this->request->getQuery('search') . '%',
		            'Customers.phone like' => '%' . $this->request->getQuery('search') . '%'
		        ]],
		        'order' => ['Customers.id' => 'DESC' ]
		    ];
		}else{
			print '<h2>Driver database dont supported!';
			exit;
		}
            
	        $this->set('customers', $this->paginate($this->Customers));
		$this->set('_serialize', ['customers']);    
    }
*/

    /**
     * View method
     *
     * @param string|null $id Verificaco id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $verificaco = $this->Verificacoes->get($id, [
            'contain' => []
        ]);

        $this->set('verificaco', $verificaco);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $verificaco = $this->Verificacoes->newEntity();
        if ($this->request->is('post')) {
            $verificaco = $this->Verificacoes->patchEntity($verificaco, $this->request->getData());
            if ($this->Verificacoes->save($verificaco)) {
                $this->Flash->success(__('verificaco foi salvo.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('verificaco não pode ser salvo. Tente novamente.'));
        }
        $this->set(compact('verificaco'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Verificaco id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $verificaco = $this->Verificacoes->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $verificaco = $this->Verificacoes->patchEntity($verificaco, $this->request->getData());
            if ($this->Verificacoes->save($verificaco)) {
                $this->Flash->success(__('verificaco foi salvo.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('verificaco não pode ser salvo(a). Tente novamente.'));
        }
        $this->set(compact('verificaco'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Verificaco id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $verificaco = $this->Verificacoes->get($id);
        if ($this->Verificacoes->delete($verificaco)) {
            $this->Flash->success(__('verificaco foi excluído(a).'));
        } else {
            $this->Flash->error(__('verificaco não pode ser excluído. Tente novamente.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
