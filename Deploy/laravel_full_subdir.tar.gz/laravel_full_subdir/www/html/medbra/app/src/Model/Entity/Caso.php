<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Cake\Auth\DefaultPasswordHasher;

/**
 * Caso Entity
 *
 * @property int $id
 * @property int $medico_id
 * @property string $titulo
 * @property string $anamnese
 * @property int $estado
 * @property int $especialidade_id
 *
 * @property \App\Model\Entity\Medico $medico
 * @property \App\Model\Entity\Especialidade $especialidade
 */
class Caso extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'medico_id' => true,
        'titulo' => true,
        'anamnese' => true,
        'estado' => true,
        'especialidade_id' => true,
        'medico' => true,
        'especialidade' => true,
    ];

    protected function _setPassword($password)
    {
        return (new DefaultPasswordHasher)->hash($password);
    }        

}
