<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Propostas Controller
 *
 * @property \App\Model\Table\PropostasTable $Propostas
 *
 * @method \App\Model\Entity\Proposta[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PropostasController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $propostas = $this->paginate($this->Propostas);

        $this->set(compact('propostas'));
    }

// Código para a busca
/*  // Descomente a linha abaixo e mova para o início, logo abaixo de use App\Controller\AppController;
	// E adapte corretamente para o seu controller
	//use Cake\Datasource\ConnectionManager;
    public function index()
    {        
		$conn = ConnectionManager::get('default');
		$driver = $conn->config()['driver']; // Outros: database, etc.
		
		if($driver == 'Cake\Database\Driver\Postgres'){
		    $this->paginate = [
		        'contain' => ['Users'],
		        'conditions' => ['or' => [
		            'Customers.name ilike' => '%' . $this->request->getQuery('search') . '%',
		            'Customers.phone ilike' => '%' . $this->request->getQuery('search') . '%'
		        ]],
		        'order' => ['Customers.id' => 'DESC' ]
		    ];
		}elseif($driver=='Cake\Database\Driver\Mysql'){
		    $this->paginate = [
		        'contain' => ['Users'],
		        'conditions' => ['or' => [
		            'Customers.name like' => '%' . $this->request->getQuery('search') . '%',
		            'Customers.phone like' => '%' . $this->request->getQuery('search') . '%'
		        ]],
		        'order' => ['Customers.id' => 'DESC' ]
		    ];
		}else{
			print '<h2>Driver database dont supported!';
			exit;
		}
            
	        $this->set('customers', $this->paginate($this->Customers));
		$this->set('_serialize', ['customers']);    
    }
*/

    /**
     * View method
     *
     * @param string|null $id Proposta id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $proposta = $this->Propostas->get($id, [
            'contain' => []
        ]);

        $this->set('proposta', $proposta);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $proposta = $this->Propostas->newEntity();
        if ($this->request->is('post')) {
            $proposta = $this->Propostas->patchEntity($proposta, $this->request->getData());
            if ($this->Propostas->save($proposta)) {
                $this->Flash->success(__('proposta foi salvo.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('proposta não pode ser salvo. Tente novamente.'));
        }
        $this->set(compact('proposta'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Proposta id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $proposta = $this->Propostas->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $proposta = $this->Propostas->patchEntity($proposta, $this->request->getData());
            if ($this->Propostas->save($proposta)) {
                $this->Flash->success(__('proposta foi salvo.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('proposta não pode ser salvo(a). Tente novamente.'));
        }
        $this->set(compact('proposta'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Proposta id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $proposta = $this->Propostas->get($id);
        if ($this->Propostas->delete($proposta)) {
            $this->Flash->success(__('proposta foi excluído(a).'));
        } else {
            $this->Flash->error(__('proposta não pode ser excluído. Tente novamente.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
