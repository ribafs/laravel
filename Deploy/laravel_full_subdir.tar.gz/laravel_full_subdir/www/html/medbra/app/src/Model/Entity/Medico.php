<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;
use Cake\Auth\DefaultPasswordHasher;

/**
 * Medico Entity
 *
 * @property int $id
 * @property string $nome
 * @property string $crm
 * @property string $cpf
 * @property string $sexo
 * @property string $foto
 * @property string $endereco
 * @property string $cidade
 * @property string $cep
 * @property string $estado
 * @property string $pais
 * @property string|null $lates
 * @property int $especialidade_id
 * @property int $user_id
 *
 * @property \App\Model\Entity\Especialidade[] $especialidades
 * @property \App\Model\Entity\User $user
 * @property \App\Model\Entity\Caso[] $casos
 */
class Medico extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'nome' => true,
        'crm' => true,
        'cpf' => true,
        'sexo' => true,
        'foto' => true,
        'endereco' => true,
        'cidade' => true,
        'cep' => true,
        'estado' => true,
        'pais' => true,
        'lates' => true,
        'especialidade_id' => true,
        'user_id' => true,
        'especialidades' => true,
        'user' => true,
        'casos' => true,
    ];

    protected function _setPassword($password)
    {
        return (new DefaultPasswordHasher)->hash($password);
    }        

}
