<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * MedicosEspecialidades Controller
 *
 * @property \App\Model\Table\MedicosEspecialidadesTable $MedicosEspecialidades
 *
 * @method \App\Model\Entity\MedicosEspecialidade[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MedicosEspecialidadesController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Medicos', 'Especialidades']
        ];
        $medicosEspecialidades = $this->paginate($this->MedicosEspecialidades);

        $this->set(compact('medicosEspecialidades'));
    }

// Código para a busca
/*  // Descomente a linha abaixo e mova para o início, logo abaixo de use App\Controller\AppController;
	// E adapte corretamente para o seu controller
	//use Cake\Datasource\ConnectionManager;
    public function index()
    {        
		$conn = ConnectionManager::get('default');
		$driver = $conn->config()['driver']; // Outros: database, etc.
		
		if($driver == 'Cake\Database\Driver\Postgres'){
		    $this->paginate = [
		        'contain' => ['Users'],
		        'conditions' => ['or' => [
		            'Customers.name ilike' => '%' . $this->request->getQuery('search') . '%',
		            'Customers.phone ilike' => '%' . $this->request->getQuery('search') . '%'
		        ]],
		        'order' => ['Customers.id' => 'DESC' ]
		    ];
		}elseif($driver=='Cake\Database\Driver\Mysql'){
		    $this->paginate = [
		        'contain' => ['Users'],
		        'conditions' => ['or' => [
		            'Customers.name like' => '%' . $this->request->getQuery('search') . '%',
		            'Customers.phone like' => '%' . $this->request->getQuery('search') . '%'
		        ]],
		        'order' => ['Customers.id' => 'DESC' ]
		    ];
		}else{
			print '<h2>Driver database dont supported!';
			exit;
		}
            
	        $this->set('customers', $this->paginate($this->Customers));
		$this->set('_serialize', ['customers']);    
    }
*/

    /**
     * View method
     *
     * @param string|null $id Medicos Especialidade id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $medicosEspecialidade = $this->MedicosEspecialidades->get($id, [
            'contain' => ['Medicos', 'Especialidades']
        ]);

        $this->set('medicosEspecialidade', $medicosEspecialidade);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $medicosEspecialidade = $this->MedicosEspecialidades->newEntity();
        if ($this->request->is('post')) {
            $medicosEspecialidade = $this->MedicosEspecialidades->patchEntity($medicosEspecialidade, $this->request->getData());
            if ($this->MedicosEspecialidades->save($medicosEspecialidade)) {
                $this->Flash->success(__('medicos especialidade foi salvo.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('medicos especialidade não pode ser salvo. Tente novamente.'));
        }
        $medicos = $this->MedicosEspecialidades->Medicos->find('list', ['limit' => 200]);
        $especialidades = $this->MedicosEspecialidades->Especialidades->find('list', ['limit' => 200]);
        $this->set(compact('medicosEspecialidade', 'medicos', 'especialidades'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Medicos Especialidade id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $medicosEspecialidade = $this->MedicosEspecialidades->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $medicosEspecialidade = $this->MedicosEspecialidades->patchEntity($medicosEspecialidade, $this->request->getData());
            if ($this->MedicosEspecialidades->save($medicosEspecialidade)) {
                $this->Flash->success(__('medicos especialidade foi salvo.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('medicos especialidade não pode ser salvo(a). Tente novamente.'));
        }
        $medicos = $this->MedicosEspecialidades->Medicos->find('list', ['limit' => 200]);
        $especialidades = $this->MedicosEspecialidades->Especialidades->find('list', ['limit' => 200]);
        $this->set(compact('medicosEspecialidade', 'medicos', 'especialidades'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Medicos Especialidade id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $medicosEspecialidade = $this->MedicosEspecialidades->get($id);
        if ($this->MedicosEspecialidades->delete($medicosEspecialidade)) {
            $this->Flash->success(__('medicos especialidade foi excluído(a).'));
        } else {
            $this->Flash->error(__('medicos especialidade não pode ser excluído. Tente novamente.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
