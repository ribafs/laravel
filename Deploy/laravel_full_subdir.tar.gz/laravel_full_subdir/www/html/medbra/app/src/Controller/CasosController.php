<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Casos Controller
 *
 * @property \App\Model\Table\CasosTable $Casos
 *
 * @method \App\Model\Entity\Caso[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CasosController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|void
     */
    public function index()
    {
        $this->paginate = [
            'contain' => ['Medicos', 'Especialidades']
        ];
        $casos = $this->paginate($this->Casos);

        $this->set(compact('casos'));
    }

// Código para a busca
/*  // Descomente a linha abaixo e mova para o início, logo abaixo de use App\Controller\AppController;
	// E adapte corretamente para o seu controller
	//use Cake\Datasource\ConnectionManager;
    public function index()
    {        
		$conn = ConnectionManager::get('default');
		$driver = $conn->config()['driver']; // Outros: database, etc.
		
		if($driver == 'Cake\Database\Driver\Postgres'){
		    $this->paginate = [
		        'contain' => ['Users'],
		        'conditions' => ['or' => [
		            'Customers.name ilike' => '%' . $this->request->getQuery('search') . '%',
		            'Customers.phone ilike' => '%' . $this->request->getQuery('search') . '%'
		        ]],
		        'order' => ['Customers.id' => 'DESC' ]
		    ];
		}elseif($driver=='Cake\Database\Driver\Mysql'){
		    $this->paginate = [
		        'contain' => ['Users'],
		        'conditions' => ['or' => [
		            'Customers.name like' => '%' . $this->request->getQuery('search') . '%',
		            'Customers.phone like' => '%' . $this->request->getQuery('search') . '%'
		        ]],
		        'order' => ['Customers.id' => 'DESC' ]
		    ];
		}else{
			print '<h2>Driver database dont supported!';
			exit;
		}
            
	        $this->set('customers', $this->paginate($this->Customers));
		$this->set('_serialize', ['customers']);    
    }
*/

    /**
     * View method
     *
     * @param string|null $id Caso id.
     * @return \Cake\Http\Response|void
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $caso = $this->Casos->get($id, [
            'contain' => ['Medicos', 'Especialidades']
        ]);

        $this->set('caso', $caso);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $caso = $this->Casos->newEntity();
        if ($this->request->is('post')) {
            $caso = $this->Casos->patchEntity($caso, $this->request->getData());
            if ($this->Casos->save($caso)) {
                $this->Flash->success(__('caso foi salvo.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('caso não pode ser salvo. Tente novamente.'));
        }
        $medicos = $this->Casos->Medicos->find('list', ['limit' => 200]);
        $especialidades = $this->Casos->Especialidades->find('list', ['limit' => 200]);
        $this->set(compact('caso', 'medicos', 'especialidades'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Caso id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $caso = $this->Casos->get($id, [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $caso = $this->Casos->patchEntity($caso, $this->request->getData());
            if ($this->Casos->save($caso)) {
                $this->Flash->success(__('caso foi salvo.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('caso não pode ser salvo(a). Tente novamente.'));
        }
        $medicos = $this->Casos->Medicos->find('list', ['limit' => 200]);
        $especialidades = $this->Casos->Especialidades->find('list', ['limit' => 200]);
        $this->set(compact('caso', 'medicos', 'especialidades'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Caso id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $caso = $this->Casos->get($id);
        if ($this->Casos->delete($caso)) {
            $this->Flash->success(__('caso foi excluído(a).'));
        } else {
            $this->Flash->error(__('caso não pode ser excluído. Tente novamente.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
