<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /backup/www/medbra/vendor/ribafs/admin-br/src/Template/Bake/Element/form.twig */
class __TwigTemplate_162abb3da0911cb3dc850fa2a44afde0e3aba12f6d2e517092e084f1513a3a87 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa = $this->env->getExtension("WyriHaximus\\TwigView\\Lib\\Twig\\Extension\\Profiler");
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->enter($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "/backup/www/medbra/vendor/ribafs/admin-br/src/Template/Bake/Element/form.twig"));

        // line 16
        $context["fields"] = $this->getAttribute(($context["Bake"] ?? null), "filterFields", [0 => ($context["fields"] ?? null), 1 => ($context["schema"] ?? null), 2 => ($context["modelObject"] ?? null)], "method");
        // line 17
        echo "<div class=\"actions columns col-lg-2 col-md-3\">
    <h3><?= __('Ações') ?></h3>

<style type=\"text/css\">
    div.input label { display: block; }

    input {\t
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;\t
    width: 100%;
    }

    textarea {\t
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;\t
    width: 100%;
    }
</style>

    <ul class=\"nav nav-stacked nav-pills\">
";
        // line 39
        if ((strpos(($context["action"] ?? null), "add") === false)) {
            // line 40
            echo "        <li><?= \$this->Form->postLink(
                __('Excluir'),
                ['action' => 'delete', \$";
            // line 42
            echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
            echo "->";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["primaryKey"] ?? null), 0, [], "array"), "html", null, true);
            echo "],
                ['confirm' => __('Deseja realmente excluir # {0}?', \$";
            // line 43
            echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
            echo "->";
            echo twig_escape_filter($this->env, $this->getAttribute(($context["primaryKey"] ?? null), 0, [], "array"), "html", null, true);
            echo ")]
            )
        ?></li>
";
        }
        // line 47
        echo "        <li class=\"active\"><?= \$this->Html->link(__('Listar ";
        echo twig_escape_filter($this->env, ($context["pluralHumanName"] ?? null), "html", null, true);
        echo "'), ['action' => 'index']) ?></li>";
        // line 48
        echo "
";
        // line 49
        $context["done"] = [];
        // line 50
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["associations"] ?? null));
        foreach ($context['_seq'] as $context["type"] => $context["data"]) {
            // line 51
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($context["data"]);
            foreach ($context['_seq'] as $context["alias"] => $context["details"]) {
                // line 52
                if (( !($this->getAttribute($context["details"], "controller", []) === $this->getAttribute(($context["_view"] ?? null), "name", [])) && !twig_in_filter($this->getAttribute($context["details"], "controller", []), ($context["done"] ?? null)))) {
                    // line 53
                    echo "        <li><?= \$this->Html->link(__('Listar ";
                    echo twig_escape_filter($this->env, Cake\Utility\Inflector::humanize(Cake\Utility\Inflector::underscore($context["alias"])), "html", null, true);
                    echo "'), ['controller' => '";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["details"], "controller", []), "html", null, true);
                    echo "', 'action' => 'index']) ?></li>
        <li><?= \$this->Html->link(__('Novo ";
                    // line 54
                    echo twig_escape_filter($this->env, Cake\Utility\Inflector::humanize(Cake\Utility\Inflector::underscore(Cake\Utility\Inflector::singularize($context["alias"]))), "html", null, true);
                    echo "'), ['controller' => '";
                    echo twig_escape_filter($this->env, $this->getAttribute($context["details"], "controller", []), "html", null, true);
                    echo "', 'action' => 'add']) ?></li>";
                    // line 55
                    echo "
";
                    // line 56
                    $context["done"] = twig_array_merge(($context["done"] ?? null), [0 => $this->getAttribute($context["details"], "controller", [])]);
                }
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['alias'], $context['details'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['data'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 60
        echo "    </ul>
</div>
<div class=\"";
        // line 62
        echo twig_escape_filter($this->env, ($context["pluralVar"] ?? null), "html", null, true);
        echo " form large-9 medium-8 columns content\">
    <?= \$this->Form->create(\$";
        // line 63
        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
        echo ") ?>
    <fieldset>
        <legend><?= __('";
        // line 65
        echo twig_escape_filter($this->env, Cake\Utility\Inflector::humanize(($context["action"] ?? null)), "html", null, true);
        echo " ";
        echo twig_escape_filter($this->env, ($context["singularHumanName"] ?? null), "html", null, true);
        echo "') ?></legend>
        <?php
";
        // line 67
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["fields"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            if (!twig_in_filter($context["field"], ($context["primaryKey"] ?? null))) {
                // line 68
                if ($this->getAttribute(($context["keyFields"] ?? null), $context["field"], [], "array")) {
                    // line 69
                    $context["fieldData"] = $this->getAttribute(($context["Bake"] ?? null), "columnData", [0 => $context["field"], 1 => ($context["schema"] ?? null)], "method");
                    // line 70
                    if ($this->getAttribute(($context["fieldData"] ?? null), "null", [])) {
                        // line 71
                        echo "            echo \$this->Form->control('";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "', ['options' => \$";
                        echo twig_escape_filter($this->env, $this->getAttribute(($context["keyFields"] ?? null), $context["field"], [], "array"), "html", null, true);
                        echo ", 'empty' => true]);";
                        // line 72
                        echo "
";
                    } else {
                        // line 74
                        echo "            echo \$this->Form->control('";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "', ['options' => \$";
                        echo twig_escape_filter($this->env, $this->getAttribute(($context["keyFields"] ?? null), $context["field"], [], "array"), "html", null, true);
                        echo "]);";
                        // line 75
                        echo "
";
                    }
                } elseif (!twig_in_filter(                // line 77
$context["field"], [0 => "created", 1 => "modified", 2 => "updated"])) {
                    // line 78
                    $context["fieldData"] = $this->getAttribute(($context["Bake"] ?? null), "columnData", [0 => $context["field"], 1 => ($context["schema"] ?? null)], "method");
                    // line 79
                    if ((twig_in_filter($this->getAttribute(($context["fieldData"] ?? null), "type", []), [0 => "date", 1 => "datetime", 2 => "time"]) && $this->getAttribute(($context["fieldData"] ?? null), "null", []))) {
                        // line 80
                        echo "            echo \$this->Form->control('";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "', ['empty' => true]);";
                        // line 81
                        echo "
";
                    } else {
                        // line 83
                        echo "            echo \$this->Form->control('";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "');";
                        // line 84
                        echo "
";
                    }
                }
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 89
        if ($this->getAttribute(($context["associations"] ?? null), "BelongsToMany", [])) {
            // line 90
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["associations"] ?? null), "BelongsToMany", []));
            foreach ($context['_seq'] as $context["assocName"] => $context["assocData"]) {
                // line 91
                echo "            echo \$this->Form->control('";
                echo twig_escape_filter($this->env, $this->getAttribute($context["assocData"], "property", []), "html", null, true);
                echo "._ids', ['options' => \$";
                echo twig_escape_filter($this->env, $this->getAttribute($context["assocData"], "variable", []), "html", null, true);
                echo "]);";
                // line 92
                echo "
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['assocName'], $context['assocData'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        // line 95
        echo "        ?>
    <br>
    <?= \$this->Form->button(__('Enviar'), ['class' => 'btn-success']) ?>
    </fieldset>
    <?= \$this->Form->end() ?>
</div>
";
        
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->leave($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof);

    }

    public function getTemplateName()
    {
        return "/backup/www/medbra/vendor/ribafs/admin-br/src/Template/Bake/Element/form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  224 => 95,  216 => 92,  210 => 91,  206 => 90,  204 => 89,  194 => 84,  190 => 83,  186 => 81,  182 => 80,  180 => 79,  178 => 78,  176 => 77,  172 => 75,  166 => 74,  162 => 72,  156 => 71,  154 => 70,  152 => 69,  150 => 68,  145 => 67,  138 => 65,  133 => 63,  129 => 62,  125 => 60,  114 => 56,  111 => 55,  106 => 54,  99 => 53,  97 => 52,  93 => 51,  89 => 50,  87 => 49,  84 => 48,  80 => 47,  71 => 43,  65 => 42,  61 => 40,  59 => 39,  35 => 17,  33 => 16,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{#
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @since         2.0.0
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
#}
{% set fields = Bake.filterFields(fields, schema, modelObject) %}
<div class=\"actions columns col-lg-2 col-md-3\">
    <h3><?= __('Ações') ?></h3>

<style type=\"text/css\">
    div.input label { display: block; }

    input {\t
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;\t
    width: 100%;
    }

    textarea {\t
    -webkit-box-sizing: border-box;
    -moz-box-sizing: border-box;
    box-sizing: border-box;\t
    width: 100%;
    }
</style>

    <ul class=\"nav nav-stacked nav-pills\">
{% if strpos(action, 'add') is same as(false) %}
        <li><?= \$this->Form->postLink(
                __('Excluir'),
                ['action' => 'delete', \${{ singularVar }}->{{ primaryKey[0] }}],
                ['confirm' => __('Deseja realmente excluir # {0}?', \${{ singularVar }}->{{ primaryKey[0] }})]
            )
        ?></li>
{% endif %}
        <li class=\"active\"><?= \$this->Html->link(__('Listar {{ pluralHumanName }}'), ['action' => 'index']) ?></li>
        {{- \"\\n\" }}
{%- set done = [] %}
{% for type, data in associations %}
    {%- for alias, details in data %}
        {%- if details.controller is not same as(_view.name) and details.controller not in done %}
        <li><?= \$this->Html->link(__('Listar {{ alias|underscore|humanize }}'), ['controller' => '{{ details.controller }}', 'action' => 'index']) ?></li>
        <li><?= \$this->Html->link(__('Novo {{ alias|singularize|underscore|humanize }}'), ['controller' => '{{ details.controller }}', 'action' => 'add']) ?></li>
        {{- \"\\n\" }}
        {%- set done = done|merge([details.controller]) %}
        {%- endif %}
    {%- endfor %}
{% endfor %}
    </ul>
</div>
<div class=\"{{ pluralVar }} form large-9 medium-8 columns content\">
    <?= \$this->Form->create(\${{ singularVar }}) ?>
    <fieldset>
        <legend><?= __('{{ action|humanize }} {{ singularHumanName }}') ?></legend>
        <?php
{% for field in fields if field not in primaryKey %}
    {%- if keyFields[field] %}
        {%- set fieldData = Bake.columnData(field, schema) %}
        {%- if fieldData.null %}
            echo \$this->Form->control('{{ field }}', ['options' => \${{ keyFields[field] }}, 'empty' => true]);
            {{- \"\\n\" }}
        {%- else %}
            echo \$this->Form->control('{{ field }}', ['options' => \${{ keyFields[field] }}]);
            {{- \"\\n\" }}
        {%- endif %}
    {%- elseif field not in ['created', 'modified', 'updated'] %}
        {%- set fieldData = Bake.columnData(field, schema) %}
        {%- if fieldData.type in ['date', 'datetime', 'time'] and fieldData.null %}
            echo \$this->Form->control('{{ field }}', ['empty' => true]);
            {{- \"\\n\" }}
        {%- else %}
            echo \$this->Form->control('{{ field }}');
    {{- \"\\n\" }}
        {%- endif %}
    {%- endif %}
{%- endfor %}

{%- if associations.BelongsToMany %}
    {%- for assocName, assocData in associations.BelongsToMany %}
            echo \$this->Form->control('{{ assocData.property }}._ids', ['options' => \${{ assocData.variable }}]);
    {{- \"\\n\" }}
    {%- endfor %}
{% endif %}
        ?>
    <br>
    <?= \$this->Form->button(__('Enviar'), ['class' => 'btn-success']) ?>
    </fieldset>
    <?= \$this->Form->end() ?>
</div>
", "/backup/www/medbra/vendor/ribafs/admin-br/src/Template/Bake/Element/form.twig", "/backup/www/medbra/vendor/ribafs/admin-br/src/Template/Bake/Element/form.twig");
    }
}
