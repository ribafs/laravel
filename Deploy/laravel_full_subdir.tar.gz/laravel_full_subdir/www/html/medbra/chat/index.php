<?php
include "../../config.php";
include "config/funciones.php";

if(!isset($p)){
	$p = "inicio";
}

if(isset($enviar)){
    $hash = $link->query("SELECT * FROM users WHERE username = '$userlogin' ");
    $ret = $hash->fetch(PDO::FETCH_ASSOC);
    $pass = $ret['password'];
    $pass = password_verify($passlogin, $pass);

	if($pass){
		$_SESSION['id'] = $ret['id'];
		//alert("Seja bem-vindo ".$r['username']);
		redir("./");
	}else{
		alert("Dados inválidos");
		redir("");
	}
}

?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"/>
	<link rel="stylesheet" href="css/estilo.css"/>
	<script type="text/javascript" src="jquery.js"></script>
	<title>MEDBRA Chat</title>
<style>
.centered {
  position: fixed;
  left: 50%;
  /* bring your own prefixes */
  transform: translate(-50%, 0%);
}
</style>
</head>
<body style="background-color:#bbefb8">
<img class="centered" src="../assets/img/logo-site1.png">
	<?php
	if(isset($_SESSION['id'])){
		?>
		<br>Olá <?=nombre($_SESSION['id'])?>, seja bem vindo(a) <a href="?p=sair">Sair</a>
		<br>
		<br>

		<?php
		if(file_exists("modulos/".$p.".php")){
			include "modulos/".$p.".php";
		}else{
			echo "<i>O módulo seleccionado não existe</i> <a href='./'>Volar</a>";
		}
	}else{
		if($p!="registrate"){
		?>
		<center>
			<br><br><br>
			<h1>Entrar</h1><br><br>
			<form method="post" action="">
				<input class="campo" type="text" name="userlogin" placeholder="Usuário"/><br><br>
				<input class="campo" type="password" name="passlogin" placeholder="Senha"/><br><br>
				<button class="boton" name="enviar">Entrar</button><br><br>
			</form>
		</center>
		<?php
        }elseif($p=='sair'){
            session_start();

            session_destroy();
            header('Location: index.php');
		}else{
			?>
			<center>
			<br><br><br>
			<h1>Registrar-se!</h1><br><br>
			<form method="post" action="">
				<input class="campo" type="text" name="nombre" placeholder="Nome"/><br><br>
				<input class="campo" type="text" name="user" placeholder="Usuário"/><br><br>
				<input class="campo" type="password" name="pass" placeholder="Senha"/><br><br>
				<button class="boton" name="registrar">Registrar-se</button><br><br>
				<a href="./">Se já tens uma conta, então faz login!</a>
			</form>
		</center>
			<?php
		}
	}
	?>
</header>
</body>
</html>
