<?php
if(rol($_SESSION['id']>0)){
$link->query("DELETE FROM mensagens WHERE id = '$id'");
redir("./");
}
?>
