<?php
include "../../../config.php";
include "../config/funciones.php";
$s = $link->query("SELECT * FROM mensagens ORDER BY id DESC");
while($r=$s->fetch(PDO::FETCH_ASSOC)){
	$q = $link->query("SELECT * FROM users WHERE id = '".$r['user_id']."'");
	$ru = $q->fetch(PDO::FETCH_ASSOC);
	$usuario = $ru['username'];
	?>
	<div style="background: rgba(0,0,0,0.06);margin-top:3px;padding:5px;">
	<b><?=$usuario?></b> <?=$r['texto']?> <small style="float:right;" ><?=fecha_hora($r['fecha'])?></small>
	</div>
	<?php
}
?>
