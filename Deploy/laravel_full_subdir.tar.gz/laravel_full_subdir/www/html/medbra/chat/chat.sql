CREATE TABLE IF NOT EXISTS mensagens (
  id int NOT NULL AUTO_INCREMENT,
  user_id int NOT NULL,
  fecha datetime NOT NULL,
  texto text NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE users (
  id int NOT NULL AUTO_INCREMENT,
  username varchar(55) NOT NULL,
  password varchar(255) NOT NULL, -- hash  com
  PRIMARY KEY (id),
  UNIQUE KEY username (username)
);

INSERT INTO usuarios (id, username, password) VALUES
(1, 'super', 'super	$2y$10$JSDAQhVzicXNOPsiFxSqL.w0tAO6GDCxUMxR.uP3yWMYUTBtv6W8.');

/*
$password = password_hash("super", PASSWORD_DEFAULT);
*/
