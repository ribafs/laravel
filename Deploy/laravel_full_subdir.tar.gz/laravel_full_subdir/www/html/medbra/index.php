<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Medbra</title>

        <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
        <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic">
        <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
        <link rel="stylesheet" href="assets/fonts/simple-line-icons.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.5.2/animate.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.css">

        </head>
    <nav class="navbar navbar-light navbar-expand fixed-top bg-light navigation-clean">
        <div class="container-fluid"><a class="navbar-brand" href="#"><span style="display: none;">Medbra</span>
<img src="assets/img/logo-site1.png">
</a><button data-toggle="collapse" class="navbar-toggler" data-target="#navcol-1"></button>
            <div class="collapse navbar-collapse" id="navcol-1"><a class="btn btn-primary ml-auto" role="button" href="./app">Entrar</a></div>
        </div>
    </nav>

    <body class="antialiased">

<header id="top" class="masthead text-white text-center" style="background:url('assets/img/bg.png')no-repeat center center;background-size:cover;">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-xl-9 mx-auto">
                    <h1 class="mb-2">Faça parte do time Medbra</h1>
                    <a href="#" class="btn btn-primary mx-auto btn-lg" data-aos="fade" type="submit">Cadastrar-se</a>
                </div>
                <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
                    <form>
                        <div class="form-row">
                            <div class="col-12 col-md-3"></div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">.</div><div class="row">.</div><div class="row">.</div><div class="row">.</div><div class="row">.</div><div class="row">.</div>
            <div class="row">
                <div class="col-xl-9 mx-auto">
                    <h1 class="mb-8"><a href="#features" class="btn btn-success mx-auto btn-lg" data-aos="fade">Clique aqui para nos conhecer 👇</a></h1>
                </div>
                <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
                    <form>
                        <div class="form-row">
                            <div class="col-12 col-md-3"></div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </header>
<section class="features-icons bg-light text-center" id="features">
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                        <div class="d-flex features-icons-icon"><i class="icon-screen-desktop m-auto text-primary" data-bs-hover-animate="pulse"></i></div>
                        <h3>Plataforma interativa</h3>
                        <p class="lead mb-0">Proporcionamos uma comunicação muito mais direta e clara sobre seus pacientes!</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                        <div class="d-flex features-icons-icon"><i class="icon-layers m-auto text-primary" data-bs-hover-animate="pulse"></i></div>
                        <h3>Histórico de diagnóstico</h3>
                        <p class="lead mb-0">Compartilhamento interno de histórico de pacientes atendidos pelos cadastrados!</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="mx-auto features-icons-item mb-5 mb-lg-0 mb-lg-3">
                        <div class="d-flex features-icons-icon"><i class="icon-check m-auto text-primary" data-bs-hover-animate="pulse"></i></div>
                        <h3>Fácil e acessível</h3>
                        <p class="lead mb-0">Interaja com facilidade e ganhe muito mais desempenho no seu trabalho!</p>
                    </div>
                </div>
                <div class="col-xl-9 mx-auto">
                    <a href="#showcase" class="btn btn-success mx-auto btn-lg" data-aos="fade"> 👇</a>
                </div>
            </div>
        </div>
    </section>
    <section class="showcase" id="showcase">
        <div class="container-fluid p-0">
            <div class="row no-gutters">
                <div class="col-lg-6 order-lg-2 text-white showcase-img" style="background-image:url(&quot;assets/img/bg-showcase-1.jpg&quot;);"><span></span></div>
                <div class="col-lg-6 my-auto order-lg-1 showcase-text">
                    <h2>Fully Responsive Design</h2>
                    <p class="lead mb-0">When you use a theme created with Bootstrap, you know that the theme will look great on any device, whether it's a phone, tablet, or desktop the page will behave responsively!</p>
                </div>
            </div>
                <div class="col-xl-9 mx-auto">
                    <a href="#bootstrap" class="btn btn-success mx-auto btn-lg" data-aos="fade"> 👇</a>
                </div>

            <div class="row no-gutters" id="bootstrap">
                <div class="col-lg-6 text-white showcase-img" style="background-image:url(&quot;{{asset('img/bg-showcase-2.jpg')}}&quot;);"><span></span></div>
                <div class="col-lg-6 my-auto order-lg-1 showcase-text">
                    <h2>Updated For Bootstrap 4</h2>
                    <p class="lead mb-0">Newly improved, and full of great utility classes, Bootstrap 4 is leading the way in mobile responsive web development! All of the themes are now using Bootstrap 4!</p>
                </div>
            </div>

            <div class="row no-gutters">
                <div class="col-lg-6 order-lg-2 text-white showcase-img" style="background-image:url(&quot;{{asset('img/bg-showcase-3.jpg')}}&quot;);"><span></span></div>
                <div class="col-lg-6 my-auto order-lg-1 showcase-text">
                    <h2>Easy to Use &amp;&nbsp;Customize</h2>
                    <p class="lead mb-0">Landing Page is just HTML and CSS with a splash of SCSS for users who demand some deeper customization options. Out of the box, just add your content and images, and your new landing page will be ready to go!</p>
                </div>
                <div class="col-xl-9 mx-auto">
                    <a href="#testimonials" class="btn btn-success mx-auto btn-lg" data-aos="fade"> 👇</a>
                </div>
            </div>
                <div class="col-xl-9 mx-auto">
                    <a href="#testimonials" class="btn btn-success mx-auto btn-lg" data-aos="fade"> 👇</a>
                </div>
        </div>
    </section>
    <section class="testimonials text-center bg-light" id="testimonials">
        <div class="container">
            <h2 class="mb-5">Depoimentos de quem usa o Medbra</h2>
            <div class="row">
                <div class="col-lg-4">
                    <div class="mx-auto testimonial-item mb-5 mb-lg-0"><img class="rounded-circle img-fluid mb-3" src="{{asset('img/testimonials-1.jpg')}}">
                        <h5>Margaret E.</h5>
                        <p class="font-weight-light mb-0">"This is fantastic! Thanks so much guys!"</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="mx-auto testimonial-item mb-5 mb-lg-0"><img class="rounded-circle img-fluid mb-3" src="{{asset('img/testimonials-2.jpg')}}">
                        <h5>Fred S.</h5>
                        <p class="font-weight-light mb-0">"Bootstrap is amazing. I've been using it to create lots of super nice landing pages."</p>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="mx-auto testimonial-item mb-5 mb-lg-0"><img class="rounded-circle img-fluid mb-3" src="{{asset('img/testimonials-3.jpg')}}">
                        <h5>Sarah W.</h5>
                        <p class="font-weight-light mb-0">"Thanks so much for making these free resources available to us!"</p>
                    </div>
                </div>
                <div class="col-xl-9 mx-auto">
                    <a href="#search" class="btn btn-success mx-auto btn-lg" data-aos="fade"> 👇</a>
                </div>
            </div>
        </div>
    </section>
    <section id="search" class="call-to-action text-white text-center" style="background:url(&quot;{{asset('img/bg.png')}}&quot;) no-repeat center center;background-size:cover;">
        <div class="overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-xl-9 mx-auto">
                    <h2 class="mb-4"><br><strong>Encontre um médico pertinho de você</strong><br></h2>
                </div>
                <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
                    <form>
                        <div class="form-row">
                            <div class="col-12 col-md-9 mb-2 mb-md-0"><input class="form-control form-control-lg" type="email" placeholder="Digte o CEP de sua cidade"></div>
                            <div class="col-12 col-md-3"><button class="btn btn-primary btn-block btn-lg" type="submit">Buscar</button></div>
                        </div>
                    </form>
                </div>
                <div class="col-md-10 col-lg-8 col-xl-7 mx-auto">
<pre>




</pre>
                </div>

                <div class="col-xl-9 mx-auto">
                    <a href="#top" class="btn btn-success mx-auto btn-lg" data-aos="fade"> 👆</a>
                </div>

            </div>
        </div>
    </section>
                <div class="flex justify-center mt-4 sm:items-center sm:justify-between">
                    <div class="text-center text-sm text-gray-500 sm:text-left">

                </div>
            </div>
        </div>
<footer class="footer bg-light">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 my-auto h-100 text-center text-lg-left">
                    <ul class="list-inline mb-2">
                        <li class="list-inline-item"><a href="#">Sobre</a></li>
                        <li class="list-inline-item"><span>⋅</span></li>
                        <li class="list-inline-item"><a href="#">Contato</a></li>
                        <li class="list-inline-item"><span>⋅</span></li>
                        <li class="list-inline-item"><a href="#">Termo de uso</a></li>
                        <li class="list-inline-item"><span>⋅</span></li>
                        <li class="list-inline-item"><a href="#">Política de privacidade</a></li>
                    </ul>
                    <p class="text-muted small mb-4 mb-lg-0">© Medbra 2021. Todos os direitos reservados</p>
                </div>
                <div class="col-lg-6 my-auto h-100 text-center text-lg-right">
                    <ul class="list-inline mb-0">
                        <li class="list-inline-item"><a href="#"><i class="fa fa-facebook fa-2x fa-fw"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-twitter fa-2x fa-fw"></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-instagram fa-2x fa-fw"></i></a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
    <script src="assets/js/bs-init.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.1.1/aos.js"></script>
    </body>
</html>
