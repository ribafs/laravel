<?php
$mysql_host = "localhost";
$mysql_user = "medbra_us";
$mysql_pass = "zmxn1029M@";
$mysql_db = "medbra_db";
?>
