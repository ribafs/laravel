<?php
header('location: medbra');
