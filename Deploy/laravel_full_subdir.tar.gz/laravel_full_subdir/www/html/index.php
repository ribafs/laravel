<?php
header('location: public');
