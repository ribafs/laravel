<?php

uses(Tests\TestCase::class)->in('Feature');
