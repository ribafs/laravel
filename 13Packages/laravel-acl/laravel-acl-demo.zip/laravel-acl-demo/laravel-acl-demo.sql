-- Adminer 4.8.0 MySQL 5.5.5-10.3.29-MariaDB-0ubuntu0.20.04.1 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `clients` (`id`, `created_at`, `updated_at`, `name`, `email`) VALUES
(1,	NULL,	NULL,	'Prof. Kennedy Predovic Jr.',	'edeckow@beer.com'),
(2,	NULL,	'2021-05-19 00:34:13',	'Annalise Johns3',	'mrenner@yahoo.com'),
(3,	NULL,	NULL,	'Colin Rowe',	'toy62@schmidt.net'),
(4,	NULL,	NULL,	'Mrs. Ivah Bartoletti II',	'jonatan.murphy@franecki.biz'),
(5,	NULL,	NULL,	'Johnathan Heidenreich PhD',	'kuhic.joaquin@hotmail.com'),
(6,	NULL,	NULL,	'Karl Kub',	'harmony48@maggio.com'),
(7,	NULL,	NULL,	'Janessa Kovacek DDS',	'leilani33@stracke.org'),
(8,	NULL,	NULL,	'Ms. Tina Okuneva I',	'duncan87@volkman.com'),
(9,	NULL,	NULL,	'Hester Adams',	'elisha04@yahoo.com'),
(10,	NULL,	NULL,	'Bernadine Heller',	'dreichert@bailey.com'),
(11,	NULL,	NULL,	'Jasper Collier Sr.',	'vernie.hammes@hotmail.com'),
(12,	NULL,	NULL,	'Roderick Graham',	'schaefer.layla@gmail.com'),
(13,	NULL,	NULL,	'Reinhold Gleichner',	'lue.klocko@gmail.com'),
(14,	NULL,	NULL,	'Destini Pfeffer',	'rodriguez.gladys@yahoo.com'),
(15,	NULL,	NULL,	'Shayna Gusikowski V',	'conn.mateo@yahoo.com'),
(16,	NULL,	NULL,	'Monroe Kreiger',	'geraldine.klocko@hoeger.com'),
(17,	NULL,	NULL,	'Mr. Bernard Reinger',	'johnson.harvey@veum.info'),
(18,	NULL,	NULL,	'Hubert Stamm',	'shawn.hyatt@hotmail.com'),
(19,	NULL,	NULL,	'Mrs. Pauline Kertzmann',	'koepp.sammy@yahoo.com'),
(20,	NULL,	NULL,	'Estelle Gusikowski',	'lonzo70@dickens.biz'),
(21,	NULL,	NULL,	'Curtis Feest',	'marilie50@krajcik.com'),
(22,	NULL,	NULL,	'Conor Wuckert',	'kenny.lesch@gmail.com'),
(23,	NULL,	NULL,	'Pearl Leannon',	'foster01@haag.com'),
(24,	NULL,	NULL,	'Stewart Heller',	'eichmann.maxime@hotmail.com'),
(25,	NULL,	NULL,	'Waldo Murray',	'moen.margie@hotmail.com'),
(26,	NULL,	NULL,	'Mark Turcotte',	'colton.ullrich@yahoo.com'),
(27,	NULL,	NULL,	'Olen Shanahan',	'rernser@gmail.com'),
(28,	NULL,	NULL,	'Danial Schmeler',	'bwitting@hotmail.com'),
(29,	NULL,	NULL,	'Savanah Anderson',	'hudson.maryjane@gmail.com'),
(30,	NULL,	NULL,	'Mr. Magnus Medhurst',	'deanna56@marquardt.com'),
(31,	NULL,	NULL,	'Scottie O\'Kon V',	'bartoletti.waldo@wunsch.info'),
(32,	NULL,	NULL,	'Monty Howe',	'olaf.anderson@yahoo.com'),
(33,	NULL,	NULL,	'Yoshiko Pagac',	'dmurphy@yahoo.com'),
(34,	NULL,	NULL,	'Jannie Deckow',	'viviane63@hansen.net'),
(35,	NULL,	NULL,	'Ms. Geraldine Wehner',	'odie.howe@yahoo.com'),
(36,	NULL,	NULL,	'Eldred Parisian I',	'kautzer.isabelle@gmail.com'),
(37,	NULL,	NULL,	'Miss Nyasia Waters IV',	'mrosenbaum@gmail.com'),
(38,	NULL,	NULL,	'Dr. Marco Monahan IV',	'jermey.hettinger@hotmail.com'),
(39,	NULL,	NULL,	'Delta Corkery II',	'cstroman@yahoo.com'),
(40,	NULL,	NULL,	'Mrs. Jalyn Volkman',	'jammie53@wyman.com'),
(41,	NULL,	NULL,	'Ben Conn',	'bframi@hotmail.com'),
(42,	NULL,	NULL,	'Maxine Hackett',	'bobbie07@kuhn.com'),
(43,	NULL,	NULL,	'Zane Brown',	'burdette.dooley@oconner.com'),
(44,	NULL,	NULL,	'Annie Mayer',	'keara32@schiller.com'),
(45,	NULL,	NULL,	'Nathen Beatty',	'eschmitt@wyman.org'),
(46,	NULL,	NULL,	'Mr. Leopoldo Sauer',	'bins.keyshawn@yahoo.com'),
(47,	NULL,	NULL,	'Ms. Anahi Nitzsche PhD',	'stiedemann.maude@leuschke.com'),
(48,	NULL,	NULL,	'Vito Spinka',	'wwintheiser@buckridge.com'),
(49,	NULL,	NULL,	'Miss Catherine Balistreri PhD',	'dillan.walter@abshire.info'),
(50,	NULL,	NULL,	'Sasha O\'Kon Jr.',	'eberge@veum.com'),
(51,	NULL,	NULL,	'Earlene Schuppe',	'mueller.carmela@gmail.com'),
(52,	NULL,	NULL,	'Selena Luettgen',	'jaden96@hotmail.com'),
(53,	NULL,	NULL,	'Bernard Ziemann',	'payton49@yahoo.com'),
(54,	NULL,	NULL,	'Fiona Wunsch',	'walter.kattie@johnston.net'),
(55,	NULL,	NULL,	'Jakayla Cremin',	'lincoln43@hotmail.com'),
(56,	NULL,	NULL,	'Mrs. Martina Fahey',	'oschulist@yahoo.com'),
(57,	NULL,	NULL,	'Ms. Mireya Medhurst',	'leonora97@gmail.com'),
(58,	NULL,	NULL,	'Mohamed Gleichner',	'cummerata.diamond@gmail.com'),
(59,	NULL,	NULL,	'Dr. Theo Turcotte III',	'larkin.chadrick@hotmail.com'),
(60,	NULL,	NULL,	'Prof. Vivianne Stamm V',	'ebernier@yahoo.com'),
(61,	NULL,	NULL,	'Prof. Claudine Balistreri',	'jacey25@yahoo.com'),
(62,	NULL,	NULL,	'Nakia Okuneva IV',	'cruickshank.elisabeth@gmail.com'),
(63,	NULL,	NULL,	'Melyna Nikolaus',	'amya.beier@schowalter.com'),
(64,	NULL,	NULL,	'Shemar Legros Sr.',	'dewitt23@gmail.com'),
(65,	NULL,	NULL,	'Janis Doyle',	'wilderman.zella@gmail.com'),
(66,	NULL,	NULL,	'Ole Schowalter',	'zhagenes@homenick.info'),
(67,	NULL,	NULL,	'Miss Jewell Satterfield',	'abelardo72@hotmail.com'),
(68,	NULL,	NULL,	'Mr. Antone Jenkins DVM',	'strosin.meaghan@hotmail.com'),
(69,	NULL,	NULL,	'Zena Larson',	'cklocko@yahoo.com'),
(70,	NULL,	NULL,	'Ivy Denesik',	'simonis.destany@yahoo.com'),
(71,	NULL,	NULL,	'Sigmund Ondricka',	'lkirlin@gmail.com'),
(72,	NULL,	NULL,	'Mr. Jocelyn Braun',	'gorczany.marina@hotmail.com'),
(73,	NULL,	NULL,	'Arvel Purdy',	'devyn.tromp@gmail.com'),
(74,	NULL,	NULL,	'Johnson Schultz IV',	'reynolds.mara@feest.com'),
(75,	NULL,	NULL,	'Dr. Loyce Herzog',	'rbeahan@yahoo.com'),
(76,	NULL,	NULL,	'Amira Cremin',	'bode.allene@yahoo.com'),
(77,	NULL,	NULL,	'Romaine Tillman',	'hintz.ephraim@brekke.org'),
(78,	NULL,	NULL,	'Miss Juana Rogahn',	'smitham.jessie@gmail.com'),
(79,	NULL,	NULL,	'Dr. Ellsworth Pouros',	'lindgren.thurman@hotmail.com'),
(80,	NULL,	NULL,	'Josue Bartoletti',	'ankunding.lura@hotmail.com'),
(81,	NULL,	NULL,	'Prof. Blanca Jones',	'bette63@hotmail.com'),
(82,	NULL,	NULL,	'Ezekiel Goodwin DVM',	'tiffany.stracke@yahoo.com'),
(83,	NULL,	NULL,	'Micaela Effertz',	'gsenger@hotmail.com'),
(84,	NULL,	NULL,	'Carmel Ratke',	'orpha37@terry.com'),
(85,	NULL,	NULL,	'Alivia Gaylord',	'joanie.torphy@gmail.com'),
(86,	NULL,	NULL,	'Thea Feil',	'aglae10@bechtelar.com'),
(87,	NULL,	NULL,	'Eli Kerluke',	'brendan51@cormier.com'),
(88,	NULL,	NULL,	'Gay Terry',	'jamey.durgan@parisian.biz'),
(89,	NULL,	NULL,	'Mr. Paris Mayert MD',	'brody46@kozey.org'),
(90,	NULL,	NULL,	'Brigitte Cruickshank MD',	'natalia69@hotmail.com'),
(91,	NULL,	NULL,	'Mrs. Palma Wilkinson',	'nettie37@gmail.com'),
(92,	NULL,	NULL,	'Miss Anabel Jacobs Sr.',	'dweimann@yahoo.com'),
(93,	NULL,	NULL,	'Isai Keebler',	'russel.delores@kilback.info'),
(94,	NULL,	NULL,	'Bulah Goyette',	'twisozk@murazik.com'),
(95,	NULL,	NULL,	'Ms. Florence Harber PhD',	'elissa58@sanford.com'),
(96,	NULL,	NULL,	'Dr. Ken Rutherford',	'novella12@hotmail.com'),
(97,	NULL,	NULL,	'Robb Blanda',	'harmony92@waelchi.com'),
(98,	NULL,	NULL,	'Sandy Marquardt',	'santos.wisoky@hotmail.com'),
(99,	NULL,	NULL,	'Jocelyn Beatty',	'alden22@padberg.biz'),
(100,	NULL,	NULL,	'Casandra Kessler Sr.',	'fiona09@gmail.com'),
(101,	NULL,	NULL,	'Hester Gerhold',	'darrin.mayert@hotmail.com');

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1,	'2014_10_12_000000_create_users_table',	1),
(2,	'2014_10_12_100000_create_password_resets_table',	1),
(3,	'2014_10_12_200000_add_two_factor_columns_to_users_table',	1),
(4,	'2019_08_19_000000_create_failed_jobs_table',	1),
(5,	'2019_12_14_000001_create_personal_access_tokens_table',	1),
(6,	'2020_05_21_100000_create_teams_table',	1),
(7,	'2020_05_21_200000_create_team_user_table',	1),
(8,	'2020_05_21_300000_create_team_invitations_table',	1),
(9,	'2020_09_23_103045_create_permissions_table',	1),
(10,	'2020_09_23_103052_create_roles_table',	1),
(11,	'2020_09_23_103354_create_user_permission_table',	1),
(12,	'2020_09_23_103444_create_user_role_table',	1),
(13,	'2020_09_23_103613_create_role_permission_table',	1),
(14,	'2020_09_23_195121_create_clients_table',	1),
(15,	'2020_11_27_223439_create_products_table',	1),
(16,	'2021_04_20_084558_create_sessions_table',	1);

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1,	'All permissions',	'all-all',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(2,	'Users all',	'users-all',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(3,	'Roless all',	'roles-all',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(4,	'Permissions all',	'permissions-all',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(5,	'Clients all',	'clients-all',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(6,	'Products all',	'products-all',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(7,	'Clients index',	'clients-index',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54');

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products` (`id`, `created_at`, `updated_at`, `name`, `price`) VALUES
(1,	NULL,	NULL,	'Estella Cartwright',	33.22),
(2,	NULL,	NULL,	'Skylar Volkman',	78.84),
(3,	NULL,	NULL,	'Kameron Thompson',	61.17),
(4,	NULL,	NULL,	'Chet Bruen III',	60.36),
(5,	NULL,	NULL,	'Mr. Bernie Ferry II',	35.56),
(6,	NULL,	NULL,	'Lilliana Batz',	10.44),
(7,	NULL,	NULL,	'Mr. Braden Davis',	40.36),
(8,	NULL,	NULL,	'Dennis Collier',	25.11),
(9,	NULL,	NULL,	'Burnice Greenholt',	92.02),
(10,	NULL,	NULL,	'Prof. Flossie Schaden Sr.',	88.35),
(11,	NULL,	NULL,	'Rachel Denesik',	48.89),
(12,	NULL,	NULL,	'Ms. Maude Lockman DVM',	73.81),
(13,	NULL,	NULL,	'Kenneth Abshire',	37.16),
(14,	NULL,	NULL,	'Elizabeth Monahan III',	79.31),
(15,	NULL,	NULL,	'Antwon Mayer',	32.47),
(16,	NULL,	NULL,	'Ms. Zita Homenick MD',	61.02),
(17,	NULL,	NULL,	'Dr. Favian Schulist Sr.',	92.78),
(18,	NULL,	NULL,	'Victoria Herman',	48.11),
(19,	NULL,	NULL,	'Prof. Carter Medhurst I',	23.16),
(20,	NULL,	NULL,	'Dessie O\'Conner',	35.24),
(21,	NULL,	NULL,	'Dr. Easter Hettinger',	78.93),
(22,	NULL,	NULL,	'Miss Dortha Towne',	97.20),
(23,	NULL,	NULL,	'Gabrielle Grant',	23.48),
(24,	NULL,	NULL,	'Miss Enola Klocko',	51.61),
(25,	NULL,	NULL,	'Nella McGlynn',	50.90),
(26,	NULL,	NULL,	'Miss Melisa Kerluke IV',	34.67),
(27,	NULL,	NULL,	'Ramiro Grant',	87.86),
(28,	NULL,	NULL,	'Mr. Barton Beahan',	10.56),
(29,	NULL,	NULL,	'Adelle Marks',	49.16),
(30,	NULL,	NULL,	'Bernadette Kassulke III',	84.52),
(31,	NULL,	NULL,	'Jany Padberg V',	19.22),
(32,	NULL,	NULL,	'Eriberto McCullough',	78.74),
(33,	NULL,	NULL,	'Rosemarie Reichel',	55.65),
(34,	NULL,	NULL,	'Lesly Fisher DDS',	44.54),
(35,	NULL,	NULL,	'Fay Bogisich',	68.72),
(36,	NULL,	NULL,	'Mose Jacobi',	40.89),
(37,	NULL,	NULL,	'Dr. Julius Mertz I',	76.45),
(38,	NULL,	NULL,	'Jedidiah Gleichner',	28.76),
(39,	NULL,	NULL,	'Zoey Ankunding',	38.25),
(40,	NULL,	NULL,	'Don Zieme',	19.03),
(41,	NULL,	NULL,	'Dr. Domenic Harber II',	27.37),
(42,	NULL,	NULL,	'Madyson Dach',	75.17),
(43,	NULL,	NULL,	'Prof. Bernadette Watsica',	65.95),
(44,	NULL,	NULL,	'Kaela Bashirian DVM',	35.02),
(45,	NULL,	NULL,	'Mrs. Lelah Brekke',	83.85),
(46,	NULL,	NULL,	'Zechariah Beer DDS',	84.49),
(47,	NULL,	NULL,	'Paris Jaskolski',	91.99),
(48,	NULL,	NULL,	'Prof. Abbigail Frami MD',	94.92),
(49,	NULL,	NULL,	'Mr. Lawson Rowe',	63.00),
(50,	NULL,	NULL,	'Baby Medhurst PhD',	80.39),
(51,	NULL,	NULL,	'Victor Grimes',	35.40),
(52,	NULL,	NULL,	'Ed Bode',	17.45),
(53,	NULL,	NULL,	'Dr. Vanessa Kemmer DVM',	37.48),
(54,	NULL,	NULL,	'Hallie Reinger',	89.43),
(55,	NULL,	NULL,	'Prof. Nicola Mitchell',	89.11),
(56,	NULL,	NULL,	'Susie Orn',	74.73),
(57,	NULL,	NULL,	'Nelda Miller',	53.82),
(58,	NULL,	NULL,	'Josie Morissette I',	36.56),
(59,	NULL,	NULL,	'Trevion Hoppe',	78.07),
(60,	NULL,	NULL,	'Agnes Harvey',	83.92),
(61,	NULL,	NULL,	'Everette Rau',	74.27),
(62,	NULL,	NULL,	'Ms. Lenora Okuneva',	90.44),
(63,	NULL,	NULL,	'Gloria Monahan',	31.39),
(64,	NULL,	NULL,	'Elenora Schuster',	64.27),
(65,	NULL,	NULL,	'Dr. Helmer Lemke',	55.76),
(66,	NULL,	NULL,	'Stephanie Braun',	21.39),
(67,	NULL,	NULL,	'Miss Rosetta Mosciski',	16.60),
(68,	NULL,	NULL,	'Ted Champlin',	90.98),
(69,	NULL,	NULL,	'Bettie Bednar',	27.84),
(70,	NULL,	NULL,	'Antonio Moen',	39.48),
(71,	NULL,	NULL,	'Prof. Claudia Willms',	15.16),
(72,	NULL,	NULL,	'Dr. Branson Cummings',	95.01),
(73,	NULL,	NULL,	'Mr. Efren Will',	28.21),
(74,	NULL,	NULL,	'Ericka Senger',	48.72),
(75,	NULL,	NULL,	'Ms. Mercedes Bauch',	69.32),
(76,	NULL,	NULL,	'Lacey Stehr',	10.24),
(77,	NULL,	NULL,	'Dr. Marjory Brown',	37.05),
(78,	NULL,	NULL,	'Ms. Elisabeth McKenzie DVM',	58.15),
(79,	NULL,	NULL,	'Eliezer Mueller',	63.09),
(80,	NULL,	NULL,	'Jolie Kreiger',	85.15),
(81,	NULL,	NULL,	'Annette Zulauf',	74.82),
(82,	NULL,	NULL,	'Maud Halvorson',	76.86),
(83,	NULL,	NULL,	'Prof. Keira Lemke DDS',	93.67),
(84,	NULL,	NULL,	'Ms. Shanna Daniel',	44.61),
(85,	NULL,	NULL,	'Isadore Kunde',	64.06),
(86,	NULL,	NULL,	'Kiley Parker',	42.92),
(87,	NULL,	NULL,	'Edyth Cremin IV',	45.61),
(88,	NULL,	NULL,	'Dr. Misty Becker I',	96.67),
(89,	NULL,	NULL,	'Magdalena Effertz',	95.65),
(90,	NULL,	NULL,	'Arianna Goodwin',	65.41),
(91,	NULL,	NULL,	'Hubert O\'Conner',	43.12),
(92,	NULL,	NULL,	'Dr. Damien Schoen MD',	10.29),
(93,	NULL,	NULL,	'Domenic Rice',	19.29),
(94,	NULL,	NULL,	'Cheyenne Parker',	30.65),
(95,	NULL,	NULL,	'Chandler Collins',	97.74),
(96,	NULL,	NULL,	'Wilbert Aufderhar',	61.09),
(97,	NULL,	NULL,	'Dr. Brody Auer',	85.44),
(98,	NULL,	NULL,	'Mr. Samson Bartell III',	38.28),
(99,	NULL,	NULL,	'Enrico Breitenberg',	88.48),
(100,	NULL,	NULL,	'Francesco Franecki',	41.64),
(101,	NULL,	NULL,	'Dr. Riley Donnelly',	71.45);

DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(1,	'Super role',	'super',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(2,	'Admin role',	'admin',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(3,	'Manager role',	'manager',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(4,	'Uer role',	'user',	'2021-04-20 17:21:54',	'2021-04-20 17:21:54');

DROP TABLE IF EXISTS `role_permission`;
CREATE TABLE `role_permission` (
  `role_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `role_permission_permission_id_foreign` (`permission_id`),
  CONSTRAINT `role_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_permission_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `role_permission` (`role_id`, `permission_id`) VALUES
(1,	1),
(2,	2),
(2,	3),
(2,	4),
(3,	5),
(3,	6),
(4,	7);

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('Blx3vpQbqh05SExhEPsbDv6MpRvM0btI1j89ySEJ',	1,	'127.0.0.1',	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0',	'YTo3OntzOjY6Il90b2tlbiI7czo0MDoiYnJxNlZrcFl1WTBSUG52UjJHUnZTOFFjMGFLUGk3M3g5N1YwR0s4ZCI7czozOiJ1cmwiO2E6MDp7fXM6OToiX3ByZXZpb3VzIjthOjE6e3M6MzoidXJsIjtzOjM2OiJodHRwOi8vMTI3LjAuMC4xOjgwMDAvYWRtaW4vcHJvZHVjdHMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTAkcHpra2NEei5WMG41N0pEMkdhMUxvZWEwOGNEQzREUFIwY01qYUtsL1FYaWZWd1RtSlFLUGkiO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJ5JDEwJHB6a2tjRHouVjBuNTdKRDJHYTFMb2VhMDhjREM0RFBSMGNNamFLbC9RWGlmVndUbUpRS1BpIjt9',	1621373880),
('mlrEnPgpmLPSJdYYUMIT7ZCWfhdPKGbsyj93OPMp',	1,	'127.0.0.1',	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0',	'YTo2OntzOjY6Il90b2tlbiI7czo0MDoidVlkQkFUbGJDTnBGcHE1akFHandxc09Oa2k0REx6aWxqVTkxQjRCYyI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDM6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi9wcm9kdWN0cy8xL2VkaXQiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6MTc6InBhc3N3b3JkX2hhc2hfd2ViIjtzOjYwOiIkMnkkMTAkcHpra2NEei5WMG41N0pEMkdhMUxvZWEwOGNEQzREUFIwY01qYUtsL1FYaWZWd1RtSlFLUGkiO3M6MjE6InBhc3N3b3JkX2hhc2hfc2FuY3R1bSI7czo2MDoiJDJ5JDEwJHB6a2tjRHouVjBuNTdKRDJHYTFMb2VhMDhjREM0RFBSMGNNamFLbC9RWGlmVndUbUpRS1BpIjt9',	1621447333),
('uvVGreylOZXYeYERdjT0RBroTz3gKes06FoUAibc',	1,	'127.0.0.1',	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0',	'YTo2OntzOjY6Il90b2tlbiI7czo0MDoiNmlteTBXZkc4dTRvdnRkMGZLUEszWlFnb2hCSXZBeng1UmgwbERSdyI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6MzU6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9hZG1pbi9jbGllbnRzIjt9czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjE3OiJwYXNzd29yZF9oYXNoX3dlYiI7czo2MDoiJDJ5JDEwJHB6a2tjRHouVjBuNTdKRDJHYTFMb2VhMDhjREM0RFBSMGNNamFLbC9RWGlmVndUbUpRS1BpIjtzOjIxOiJwYXNzd29yZF9oYXNoX3NhbmN0dW0iO3M6NjA6IiQyeSQxMCRwemtrY0R6LlYwbjU3SkQyR2ExTG9lYTA4Y0RDNERQUjBjTWphS2wvUVhpZlZ3VG1KUUtQaSI7fQ==',	1618922571),
('vB1TqUZ7CLzTWZnUGuNbJvy5KPa8LeklQE2PMut6',	NULL,	'127.0.0.1',	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoidnJnQlBkV0xoSXBMTnBzS2w0SmJPRU9NblhKc0F1OEtoTHljRXdtNCI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDA6Imh0dHA6Ly9iYWNrdXAvbGFyYXZlbC9sYXJhdmVsLWFjbC9wdWJsaWMiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1618923309),
('vWJtB0TNhPXQlbmZp7k7uSX9btEY2k1EHkqWsD5M',	NULL,	'127.0.0.1',	'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:88.0) Gecko/20100101 Firefox/88.0',	'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVU5FRWxYMnU4Vnkxb1pyaFlKRGtLUkxyOUNqU0JpNFRQWWdBQ1hFaSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NDM6Imh0dHA6Ly9iYWNrdXAvbGFyYXZlbC1hY2wtZGVtby9wdWJsaWMvbG9naW4iO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19',	1621447273);

DROP TABLE IF EXISTS `teams`;
CREATE TABLE `teams` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `personal_team` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `teams_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `team_invitations`;
CREATE TABLE `team_invitations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint(20) unsigned NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_invitations_team_id_email_unique` (`team_id`,`email`),
  CONSTRAINT `team_invitations_team_id_foreign` FOREIGN KEY (`team_id`) REFERENCES `teams` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `team_user`;
CREATE TABLE `team_user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `team_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `team_user_team_id_user_id_unique` (`team_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `two_factor_secret` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `two_factor_recovery_codes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_team_id` bigint(20) unsigned DEFAULT NULL,
  `profile_photo_path` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `two_factor_secret`, `two_factor_recovery_codes`, `remember_token`, `current_team_id`, `profile_photo_path`, `created_at`, `updated_at`) VALUES
(1,	'Super user',	'super@mail.org',	NULL,	'$2y$10$pzkkcDz.V0n57JD2Ga1Loea08cDC4DPR0cMjaKl/QXifVwTmJQKPi',	NULL,	NULL,	NULL,	NULL,	NULL,	'2021-04-20 17:21:54',	'2021-04-20 17:21:54'),
(2,	'Admin user',	'admin@mail.org',	NULL,	'$2y$10$tWucYD/zBhtTqmR.z.291eh2jyhVcHpzEnurW5IOHbSC3Q.F8UOmG',	NULL,	NULL,	NULL,	NULL,	NULL,	'2021-04-20 17:21:55',	'2021-04-20 17:21:55'),
(3,	'Manager user',	'manager@mail.org',	NULL,	'$2y$10$w0.rg5EwHhciJnWTgXLWqOMO8oqbzMhaF5ILPL80sWbCqx9rO1sCC',	NULL,	NULL,	NULL,	NULL,	NULL,	'2021-04-20 17:21:55',	'2021-04-20 17:21:55'),
(4,	'User user',	'user@mail.org',	NULL,	'$2y$10$wTSJDwEHEMOB4nWU8b6A9eVbSqaiLaaAAT8QzpiIIsv9XfpH2yLVe',	NULL,	NULL,	NULL,	NULL,	NULL,	'2021-04-20 17:21:55',	'2021-04-20 17:21:55');

DROP TABLE IF EXISTS `user_permission`;
CREATE TABLE `user_permission` (
  `user_id` bigint(20) unsigned NOT NULL,
  `permission_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`permission_id`),
  KEY `user_permission_permission_id_foreign` (`permission_id`),
  CONSTRAINT `user_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_permission_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_permission` (`user_id`, `permission_id`) VALUES
(1,	1),
(2,	2),
(2,	3),
(2,	4),
(3,	5),
(3,	6),
(4,	7);

DROP TABLE IF EXISTS `user_role`;
CREATE TABLE `user_role` (
  `user_id` bigint(20) unsigned NOT NULL,
  `role_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `user_role_role_id_foreign` (`role_id`),
  CONSTRAINT `user_role_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE,
  CONSTRAINT `user_role_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `user_role` (`user_id`, `role_id`) VALUES
(1,	1),
(2,	2),
(3,	3),
(4,	4);

-- 2021-05-19 18:02:24
