<div class="col-md-2">
    <div class="card">
        <div class="card-header bg-success">
            Menu
        </div>

        <div class="card-body bg-dark text-secondary">
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="{{ url('/clientsp') }}">
                        - Clients
                    </a>
                </li>
            </ul>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="{{ url('/productsp') }}">
                        - Products
                    </a>
                </li>
            </ul>
            <hr>
        </div>
    </div>
</div>
