

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php if(auth()->check() && auth()->user()->hasRole('super', 'manager', 'user')) : ?>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header bg-success">Client <?php echo e($client->id); ?></div>
                    <div class="card-body bg-light">

                        <a href="<?php echo e(url('/admin/clients')); ?>" title="Back"><button class="btn btn-warning btn-sm"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
            <?php if(auth()->check() && auth()->user()->hasRole('super', 'manager')) : ?>
                        <a href="<?php echo e(url('/admin/clients/' . $client->id . '/edit')); ?>" title="Edit Client"><button class="btn btn-primary btn-sm"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit</button></a>

                        <form method="POST" action="<?php echo e(url('admin/clients' . '/' . $client->id)); ?>" accept-charset="UTF-8" style="display:inline">
                            <?php echo e(method_field('DELETE')); ?>

                            <?php echo e(csrf_field()); ?>

                            <button type="submit" class="btn btn-danger btn-sm" title="Delete Client" onclick="return confirm(&quot;Confirm delete?&quot;)"><i class="fa fa-trash-o" aria-hidden="true"></i> Delete</button>
                        </form>
            <?php endif; ?>
                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table class="table">
                                <tbody>
                                    <tr>
                                        <th>ID</th><td><?php echo e($client->id); ?></td>
                                    </tr>
                                    <tr><th> Name </th><td> <?php echo e($client->name); ?> </td></tr><tr><th> Email </th><td> <?php echo e($client->email); ?> </td></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /backup/www/laravel/laravel-acl/resources/views/admin/clients/show.blade.php ENDPATH**/ ?>