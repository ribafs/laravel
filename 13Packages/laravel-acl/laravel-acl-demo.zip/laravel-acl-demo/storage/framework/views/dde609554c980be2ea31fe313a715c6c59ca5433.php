<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <label for="name" class="control-label"><?php echo e('Name'); ?></label>
    <input class="form-control" name="name" type="text" id="name" value="<?php echo e(isset($product->name) ? $product->name : ''); ?>" >
    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
    <label for="price" class="control-label"><?php echo e('Price'); ?></label>
    <input class="form-control" name="price" type="number" id="price" value="<?php echo e(isset($product->price) ? $product->price : ''); ?>" >
    <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH /backup/www/laravel-acl-demo/resources/views/admin/products/form.blade.php ENDPATH**/ ?>