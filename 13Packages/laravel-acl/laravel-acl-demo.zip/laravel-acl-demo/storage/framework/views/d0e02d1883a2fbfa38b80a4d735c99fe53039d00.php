<div class="form-group <?php echo e($errors->has('name') ? 'has-error' : ''); ?>">
    <label for="name" class="control-label"><?php echo e('Name'); ?></label>
    <input class="form-control" name="name" type="text" id="name" value="<?php echo e(isset($permission->name) ? $permission->name : ''); ?>" >
    <?php echo $errors->first('name', '<p class="help-block">:message</p>'); ?>

</div>
<div class="form-group <?php echo e($errors->has('slug') ? 'has-error' : ''); ?>">
    <label for="slug" class="control-label"><?php echo e('Slug'); ?></label>
    <input class="form-control" name="slug" type="text" id="slug" value="<?php echo e(isset($permission->slug) ? $permission->slug : ''); ?>" >
    <?php echo $errors->first('slug', '<p class="help-block">:message</p>'); ?>

</div>


<div class="form-group">
    <input class="btn btn-primary" type="submit" value="<?php echo e($formMode === 'edit' ? 'Update' : 'Create'); ?>">
</div>
<?php /**PATH /backup/www/laravel/laravel-acl/resources/views/admin/permissions/form.blade.php ENDPATH**/ ?>