<div class="col-md-2">
    <div class="card">
        <div class="card-header bg-success">
            Menu
        </div>

        <div class="card-body bg-dark text-white">
      <?php if(auth()->check() && auth()->user()->hasRole('super')) : ?>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/users')); ?>">
                        - Users
                    </a>
                </li>
            </ul>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/roles')); ?>">
                        - Roles
                    </a>
                </li>
            </ul>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/permissions')); ?>">
                        - Permissions
                    </a>
                </li>
            </ul>
            <hr>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/clients')); ?>">
                        - Clients
                    </a>
                </li>
            </ul>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/products')); ?>">
                        - Products
                    </a>
                </li>
            </ul>
            <hr>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('admin')) : ?>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/users')); ?>">
                        - Users
                    </a>
                </li>
            </ul>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/roles')); ?>">
                        - Roles
                    </a>
                </li>
            </ul>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/permissions')); ?>">
                        - Permissions
                    </a>
                </li>
            </ul>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('manager')) : ?>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/clients')); ?>">
                        - Clients
                    </a>
                </li>
            </ul>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/products')); ?>">
                        - Products
                    </a>
                </li>
            </ul>
      <?php endif; ?>
      <?php if(auth()->check() && auth()->user()->hasRole('user')) : ?>
            <ul class="nav" role="tablist">
                <li role="presentation">
                    <a class="text-white" href="<?php echo e(url('/admin/clients')); ?>">
                        - Clients
                    </a>
                </li>
            </ul>
      <?php endif; ?>
        </div>
    </div>
</div>
<?php /**PATH /backup/www/laravel/laravel-acl/resources/views/includes/sidebar.blade.php ENDPATH**/ ?>