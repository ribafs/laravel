<?php echo $__env->make('errors.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <h3 align="center">Este demo permite somente SELECT para tudo.<br>As demais operações estão bloqueadas.</h3><br>
        <div class="text-center"><button onclick="goBack()">Voltar</button></div>
    </div>

<script>
function goBack() {
  window.history.back();
}
</script> 
<?php /**PATH /backup/www/laravel-acl-demo/resources/views/errors/500.blade.php ENDPATH**/ ?>