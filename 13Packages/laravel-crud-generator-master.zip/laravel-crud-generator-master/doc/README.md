# Documentation

This documentation will guide you to generate your stuffs for your application. Let's begin!

## Getting Started

1. [Installation](installation.md)
2. [Configuration](configuration.md)
3. [Usage](usage.md)
4. [Fields](fields.md)
5. [Options](options.md)
6. [Templates](templates.md)
